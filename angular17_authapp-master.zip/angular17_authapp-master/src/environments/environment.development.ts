export const environment = {
    apiUrl:'https://localhost:7143/api/'
};
