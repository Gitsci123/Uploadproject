export interface customer {
    code: string;
    name: string
    email: string
    phone: string
    creditlimit: number
    isActive: boolean,
    statusname: string
}

